from django.shortcuts import render
from .models import Category,Product
# Create your views here.
def Home(req):
    obj=Product.objects.all()
    return render(req,'index.html',{"product":obj})